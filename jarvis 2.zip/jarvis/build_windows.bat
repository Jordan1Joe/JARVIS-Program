@echo off
REM Run this ON WINDOWS to produce JARVIS.exe in the dist\ folder,
REM and — if Inno Setup is installed — a one-click JARVIS-Setup.exe
REM installer in the Output\ folder too.
pip install -r requirements.txt
pip install pyinstaller
pyinstaller jarvis.spec

echo.
echo JARVIS.exe built. Checking for Inno Setup to build the installer...

where /q ISCC.exe
if %errorlevel%==0 (
    ISCC.exe installer.iss
    echo.
    echo Done. Find JARVIS-Setup.exe in the Output folder — that's your one-click installer.
) else (
    if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" (
        "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer.iss
        echo.
        echo Done. Find JARVIS-Setup.exe in the Output folder — that's your one-click installer.
    ) else (
        echo.
        echo Inno Setup isn't installed, so only the raw JARVIS.exe was built.
        echo Install Inno Setup free from https://jrsoftware.org/isdl.php and re-run this
        echo script to also get the one-click JARVIS-Setup.exe installer.
    )
)
pause
