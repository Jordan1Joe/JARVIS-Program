#!/usr/bin/env bash
# Run this ON macOS or LINUX to produce a standalone JARVIS app/binary in dist/.
set -e
pip install -r requirements.txt
pip install pyinstaller
pyinstaller jarvis.spec
echo ""
echo "Done. Find the JARVIS app/binary in the dist/ folder."
