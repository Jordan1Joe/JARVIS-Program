"""
JARVIS Core Engine
------------------
Handles text-to-speech, speech recognition, command storage, and
launching applications when a voice command is matched.
"""

import os
import json
import time
import asyncio
import platform
import subprocess
import tempfile
import threading
import difflib
from datetime import datetime

import pyttsx3
import speech_recognition as sr

try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False

try:
    from playsound import playsound
    PLAYSOUND_AVAILABLE = True
except ImportError:
    PLAYSOUND_AVAILABLE = False

try:
    import numpy as np
    from pydub import AudioSegment
    ROBOTIC_FX_AVAILABLE = True
except ImportError:
    ROBOTIC_FX_AVAILABLE = False


CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".jarvis")
COMMANDS_FILE = os.path.join(CONFIG_DIR, "commands.json")
SETTINGS_FILE = os.path.join(CONFIG_DIR, "settings.json")

# en-GB-RyanNeural: a crisp, Received-Pronunciation British male voice —
# the closest free neural voice to a "posh butler" JARVIS accent.
# Other good options: en-GB-ThomasNeural (male), en-GB-SoniaNeural (female).
#
# robotic_intensity controls how much synthetic "edge" is layered on top of
# the natural voice via _apply_robotic_effect(): "off", "subtle" (default),
# "medium", or "heavy".
DEFAULT_SETTINGS = {
    "user_name": "Joseph",
    "wake_word": "jarvis",
    "voice": "en-GB-RyanNeural",
    "robotic_intensity": "subtle",
}


def ensure_config():
    os.makedirs(CONFIG_DIR, exist_ok=True)
    if not os.path.exists(COMMANDS_FILE):
        with open(COMMANDS_FILE, "w") as f:
            json.dump({}, f, indent=2)
    if not os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "w") as f:
            json.dump(DEFAULT_SETTINGS, f, indent=2)


def load_commands():
    ensure_config()
    with open(COMMANDS_FILE) as f:
        return json.load(f)


def save_commands(commands):
    ensure_config()
    with open(COMMANDS_FILE, "w") as f:
        json.dump(commands, f, indent=2)


def load_settings():
    ensure_config()
    with open(SETTINGS_FILE) as f:
        return json.load(f)


def save_settings(settings):
    ensure_config()
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)


class JarvisEngine:
    def __init__(self, log_callback=None):
        self.log = log_callback or (lambda msg: None)

        # Offline fallback engine (used only if the neural British voice
        # can't be reached — e.g. no internet).
        self.tts_engine = pyttsx3.init()
        self.tts_engine.setProperty("rate", 175)

        self.settings = load_settings()
        self.commands = load_commands()

        self._configure_fallback_voice()
        self._warned_fallback = False

        self.recognizer = sr.Recognizer()
        self.microphone = None

        self._listening = False
        self._listen_thread = None

    # ---------------------------------------------------------- voice ----
    def _configure_fallback_voice(self):
        """Pick the closest British system voice for the offline fallback
        (quality/availability depends on the OS — e.g. macOS ships 'Daniel',
        Windows ships 'Hazel'). This only kicks in without internet."""
        try:
            voices = self.tts_engine.getProperty("voices")
            british_markers = ("en_gb", "en-gb", "british", "daniel", "hazel", "george", "arthur")
            for v in voices:
                haystack = f"{(v.name or '')} {(v.id or '')} {' '.join(getattr(v, 'languages', []) or [])}".lower()
                if any(marker in haystack for marker in british_markers):
                    self.tts_engine.setProperty("voice", v.id)
                    return
            # No British voice found on this system — fall back to any male voice.
            for v in voices:
                if "male" in (v.name or "").lower():
                    self.tts_engine.setProperty("voice", v.id)
                    return
        except Exception:
            pass  # use whatever the system default is

    def speak(self, text):
        self.log(f"JARVIS: {text}")

        if EDGE_TTS_AVAILABLE and PLAYSOUND_AVAILABLE and self._speak_neural(text):
            return

        if not self._warned_fallback:
            self.log("[Voice] Neural British voice unavailable (offline, or "
                      "edge-tts/playsound not installed) — using system voice instead.")
            self._warned_fallback = True
        self._speak_fallback(text)

    def _speak_neural(self, text):
        """High-quality British neural voice via Microsoft Edge's free TTS service,
        with a subtle robotic effect layered on top. Requires internet.
        Returns True on success, False to trigger the offline fallback."""
        voice = self.settings.get("voice", "en-GB-RyanNeural")
        mp3_path, processed_path = None, None
        try:
            fd, mp3_path = tempfile.mkstemp(suffix=".mp3")
            os.close(fd)

            async def _synthesize():
                communicate = edge_tts.Communicate(text, voice)
                await communicate.save(mp3_path)

            asyncio.run(_synthesize())

            play_path = mp3_path
            intensity = self.settings.get("robotic_intensity", "subtle")
            if ROBOTIC_FX_AVAILABLE and intensity != "off":
                processed_path = self._apply_robotic_effect(mp3_path, intensity)
                if processed_path:
                    play_path = processed_path

            playsound(play_path)
            return True
        except Exception as e:
            self.log(f"[Neural TTS error] {e}")
            return False
        finally:
            for p in (mp3_path, processed_path):
                if p and os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass

    def _apply_robotic_effect(self, mp3_path, intensity="subtle"):
        """Layers a light synthetic texture onto the natural neural voice:
        a touch of ring modulation for metallic shimmer, a very short comb
        delay for a vocoder-like edge, and mild quantization for digital
        grain. Kept subtle by default so the voice stays clearly intelligible
        and still sounds "posh British" rather than a full robot voice.
        Returns a path to a processed .wav file, or None on failure
        (caller then just plays the plain neural voice)."""
        depth_map = {"subtle": 0.14, "medium": 0.28, "heavy": 0.48}
        depth = depth_map.get(intensity, 0.14)

        try:
            audio = AudioSegment.from_file(mp3_path, format="mp3").set_channels(1)
            frame_rate = audio.frame_rate

            samples = np.array(audio.get_array_of_samples()).astype(np.float32)
            samples /= 32768.0  # normalize int16 range to [-1, 1]
            n = len(samples)
            t = np.arange(n) / frame_rate

            # 1. Ring modulation — a low carrier frequency gives a metallic
            #    shimmer without turning the voice into pure noise.
            carrier = np.sin(2 * np.pi * 32.0 * t)
            ring_modulated = samples * carrier
            wet = samples * (1 - depth) + ring_modulated * depth

            # 2. Very short comb delay — classic cheap "vocoder" edge.
            delay_samples = max(1, int(0.006 * frame_rate))  # ~6ms
            delayed = np.zeros_like(wet)
            delayed[delay_samples:] = wet[:-delay_samples]
            wet = wet * (1 - depth * 0.5) + delayed * (depth * 0.5)

            # 3. Mild bit-depth quantization for a bit of digital grain.
            bit_levels = 2 ** int(round(11 - depth * 4))  # subtle: ~10 bits
            wet = np.round(wet * bit_levels) / bit_levels

            wet = np.clip(wet, -1.0, 1.0)
            pcm = (wet * 32767.0).astype(np.int16)

            processed = AudioSegment(
                pcm.tobytes(), frame_rate=frame_rate, sample_width=2, channels=1
            )
            fd, wav_path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            processed.export(wav_path, format="wav")
            return wav_path
        except Exception as e:
            self.log(f"[Robotic effect error] {e} — playing plain voice instead.")
            return None

    def _speak_fallback(self, text):
        try:
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        except Exception as e:
            self.log(f"[TTS error] {e}")

    def greeting_phrase(self):
        hour = datetime.now().hour
        if hour < 12:
            period = "morning"
        elif hour < 18:
            period = "afternoon"
        else:
            period = "evening"
        name = self.settings.get("user_name", "Sir")
        return f"Good {period}, {name}."

    def boot(self):
        self.speak("JARVIS: SYSTEM ONLINE")
        time.sleep(0.3)
        self.speak(self.greeting_phrase())

    # ------------------------------------------------- command storage ----
    def add_command(self, phrase, app_path):
        self.commands[phrase.lower().strip()] = app_path
        save_commands(self.commands)

    def remove_command(self, phrase):
        self.commands.pop(phrase.lower().strip(), None)
        save_commands(self.commands)

    def reload_commands(self):
        self.commands = load_commands()

    # ------------------------------------------------------ app launch ----
    def launch_app(self, path):
        system = platform.system()
        try:
            if system == "Windows":
                os.startfile(path)  # noqa
            elif system == "Darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen([path])
            return True
        except Exception as e:
            self.log(f"[Launch error] {e}")
            return False

    # ---------------------------------------------------- match logic ----
    def match_command(self, heard_text):
        heard_text = heard_text.lower().strip()
        if not heard_text or not self.commands:
            return None

        best_match, best_score = None, 0.0
        for phrase in self.commands:
            if phrase in heard_text:
                return phrase
            score = difflib.SequenceMatcher(None, phrase, heard_text).ratio()
            if score > best_score:
                best_score, best_match = score, phrase

        return best_match if best_score > 0.6 else None

    def handle_utterance(self, text):
        wake_word = self.settings.get("wake_word", "jarvis")
        text_lower = text.lower()
        if wake_word not in text_lower:
            return

        command_part = text_lower.split(wake_word, 1)[1].strip(" ,.")
        name = self.settings.get("user_name", "Sir")

        if not command_part:
            self.speak(f"Yes, {name}.")
            return

        phrase = self.match_command(command_part)
        if phrase:
            app_path = self.commands[phrase]
            self.log(f"Matched command '{phrase}' -> {app_path}")
            self.speak(f"Right away, {name}.")
            self.launch_app(app_path)
        else:
            self.speak(f"I didn't recognize that command, {name}.")

    # -------------------------------------------------- listening loop ----
    def start_listening(self):
        if self._listening:
            return
        self._listening = True
        self._listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._listen_thread.start()
        self.log("Listening started...")

    def stop_listening(self):
        self._listening = False
        self.log("Listening stopped.")

    def _listen_loop(self):
        try:
            self.microphone = sr.Microphone()
        except Exception as e:
            self.log(f"[Microphone error] {e}")
            self._listening = False
            return

        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=1)

        while self._listening:
            try:
                with self.microphone as source:
                    audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=6)
                text = self.recognizer.recognize_google(audio)
                self.log(f"Heard: {text}")
                self.handle_utterance(text)
            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                continue
            except sr.RequestError as e:
                self.log(f"[Speech recognition error] {e}")
                time.sleep(2)
            except Exception as e:
                self.log(f"[Listen loop error] {e}")
                time.sleep(1)
