; Inno Setup script for JARVIS — produces a single "JARVIS-Setup.exe"
; that installs the app, adds a Start Menu entry, an optional desktop
; shortcut, and a proper uninstaller in "Add or Remove Programs".
;
; Compiled with ISCC.exe (Inno Setup's command-line compiler) — this
; happens automatically in the GitHub Actions cloud build. To compile
; it yourself on a Windows PC: install Inno Setup (jrsoftware.org),
; then run `ISCC installer.iss` from this folder AFTER running
; build_windows.bat (this script packages the JARVIS.exe it produces).

#define MyAppName "JARVIS"
#define MyAppVersion "1.0"
#define MyAppExeName "JARVIS.exe"

[Setup]
AppId={{6F2C1E1D-8B4A-4E9F-9B2E-1F1B7C1234EE}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppName}
DefaultDirName={localappdata}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
; Installs to the user's own AppData folder — no admin password/UAC prompt needed.
PrivilegesRequired=lowest
OutputDir=Output
OutputBaseFilename=JARVIS-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "dist\JARVIS.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent
