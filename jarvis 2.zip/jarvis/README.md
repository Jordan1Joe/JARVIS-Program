# J.A.R.V.I.S. — Barebones Voice Assistant

A starter version of a voice-activated desktop assistant. On launch it says
**"JARVIS: SYSTEM ONLINE"**, then a time-aware greeting **"Good evening, Joseph."**
You can bind spoken phrases to any application on your computer via **Create Command**,
then say **"Jarvis, put on some music"** (or whatever phrase you set) to have it
launch that application.

## 1. Install Python

You need Python 3.9+ installed. Check with:
```
python3 --version
```

## 2. Install dependencies

```
cd jarvis
pip install -r requirements.txt
```

**Note on PyAudio (needed for the microphone):**
- **Windows:** usually installs fine via pip. If it fails, run:
  `pip install pipwin && pipwin install pyaudio`
- **macOS:** install the portaudio library first:
  `brew install portaudio` then `pip install pyaudio`
- **Linux (Debian/Ubuntu):**
  `sudo apt install python3-pyaudio portaudio19-dev` then `pip install pyaudio`

**Note on speech recognition:** this barebones version uses Google's free
web speech API (via the `SpeechRecognition` library) for converting your
voice to text, so an internet connection is required to hear commands.

**Note on JARVIS's voice:** by default JARVIS speaks with a posh British
accent (`en-GB-RyanNeural`), streamed from Microsoft's free neural TTS
service, with a *subtle* robotic texture layered on top (a touch of ring
modulation, a short comb delay, and light digital quantization) so it
sounds a little synthetic without losing the accent or intelligibility —
closer to "posh android butler" than "text-to-speech from 1998."

This requires internet, and the robotic-effect layer requires **ffmpeg**
to be installed on your system (used by `pydub` to decode the mp3):
- **macOS:** `brew install ffmpeg`
- **Windows:** `choco install ffmpeg` (or download from ffmpeg.org and add to PATH)
- **Linux:** `sudo apt install ffmpeg`

If ffmpeg/numpy/pydub aren't available, JARVIS just plays the plain
(non-robotic) neural voice instead — it never breaks the app. And if
you're fully offline, it falls back further to your computer's built-in
system voice (trying to pick a British one if your OS has one installed,
e.g. "Daniel" on macOS or "Hazel" on Windows — though these sound
noticeably more robotic and don't get the effect layer).

To change the voice, edit `~/.jarvis/settings.json`:
- `"voice"` — a few other posh-sounding British options:
  - `en-GB-ThomasNeural` — British male, slightly warmer
  - `en-GB-SoniaNeural` — British female, RP
  - `en-GB-LibbyNeural` — British female, younger/brighter
- `"robotic_intensity"` — `"off"`, `"subtle"` (default), `"medium"`, or `"heavy"`

Click **🔊 Test Voice** in the app any time to preview the current voice.

## 3. Run it

```
python main.py
```

A window opens, JARVIS speaks its boot line and greeting, then **automatically
starts listening** — no button press needed. Just say **"Jarvis"** and it
replies **"Yes, Joseph."** (Click "Stop Listening" any time you want quiet.)

## 4. Create a voice command

1. Click **+ Create Command**.
2. Type the phrase you'll say after "Jarvis" — e.g. `put on some music`.
3. Pick the application to launch (e.g. Spotify, iTunes, a browser shortcut, etc).
4. Say: **"Jarvis, put on some music"** — it responds "Right away, Joseph"
   and launches the app.

Commands are saved to `~/.jarvis/commands.json` so they persist between runs.
Your name and wake word live in `~/.jarvis/settings.json` — edit `user_name`
there if you're not Joseph, or change `wake_word` from `"jarvis"` to anything else.

## 5. Getting a real one-click installer (JARVIS-Setup.exe)

This is packaged with **PyInstaller** (bundles Python + all dependencies
into one `.exe`) and **Inno Setup** (wraps that `.exe` into a proper
installer with a Start Menu entry, an optional desktop shortcut, and an
uninstaller that shows up in "Add or Remove Programs"). The person
receiving it just double-clicks `JARVIS-Setup.exe`, clicks Install, done
— no Python, no folders to manage, no admin password needed (it installs
to their own user folder).

There's one catch: both tools need to actually *run on Windows* to
produce a Windows installer — that can't be faked from another OS. So
either build it on a Windows PC yourself, or let a Windows machine in the
cloud do it for you (Option B — no Windows needed on your end).

**Option A — build locally on Windows**

1. Copy this whole `jarvis` folder onto a Windows PC.
2. (Optional but recommended) Install Inno Setup, free, from
   [jrsoftware.org/isdl.php](https://jrsoftware.org/isdl.php).
3. Double-click `build_windows.bat`.
4. If Inno Setup was installed, `Output\JARVIS-Setup.exe` is your
   one-click installer. Either way, `dist\JARVIS.exe` (the raw app) is
   also there.

*(macOS/Linux equivalent: run `./build_mac_linux.sh` — this builds the
raw app only; Inno Setup is Windows-only, macOS/Linux use different
packaging conventions if you want that later.)*

**Option B — build in the cloud via GitHub Actions (no Windows needed)**

This repo already includes `.github/workflows/build-windows.yml`, which
spins up a real Windows machine in the cloud, installs Inno Setup itself,
builds both files, and hands them back as downloadable artifacts:

1. Push this `jarvis` folder to a new GitHub repository.
2. Go to the **Actions** tab of your repo — the workflow runs automatically.
   (Or click **Run workflow** to trigger it manually.)
3. When it finishes (a couple of minutes), open the completed run and
   download the **JARVIS-Setup-Installer** artifact — that's your
   one-click installer, built on real Windows. (**JARVIS-windows-exe**
   is also there if you'd rather hand someone the raw app instead.)

I've already test-built the PyInstaller side of this exact codebase
(Linux build, to confirm the packaging config is correct) — it completed
with no errors. The Inno Setup script follows standard, well-documented
syntax, but since Inno Setup only runs on Windows I haven't been able to
compile it myself in this sandbox — if the Actions run hits a snag on
that step, paste me the error and I'll fix it.

**Notes either way:**
- Antivirus / SmartScreen sometimes flags freshly-built, unsigned installers
  as unrecognized on first run — not malicious, just new and unsigned.
  Code-signing removes the warning but costs money and isn't necessary
  for personal use.
- The installer's checkbox for a desktop shortcut is unchecked by
  default; the Start Menu entry and uninstaller are always created.
- Drop an `icon.ico` file in this folder, point `icon='icon.ico'` in
  `jarvis.spec`, and add `SetupIconFile=icon.ico` under `[Setup]` in
  `installer.iss` if you want a custom icon throughout.
- Users still need `ffmpeg` installed for the robotic voice effect and an
  internet connection for the neural voice + speech recognition — the
  installer bundles the Python code, not those external pieces.

## Next upgrades

Ask any time — I can build out a real system-tray icon (so it runs quietly
in the background instead of a window), a proper low-power local wake-word
model (so it's not sending audio to Google constantly), multi-step
commands, or a settings panel in the GUI instead of hand-editing JSON.

## Project structure

```
jarvis/
├── main.py          # GUI (Tkinter) — window, buttons, log console
├── jarvis_core.py   # Engine — text-to-speech, speech recognition,
│                     #   command storage/matching, app launching
├── requirements.txt
├── jarvis.spec       # PyInstaller config — builds JARVIS.exe
├── installer.iss     # Inno Setup config — wraps JARVIS.exe into a one-click installer
├── build_windows.bat # Local Windows build script (exe + installer)
├── build_mac_linux.sh
├── .github/workflows/build-windows.yml  # Cloud build — produces both files
└── README.md
```
