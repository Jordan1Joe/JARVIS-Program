"""
JARVIS - Barebones Voice Assistant
-----------------------------------
Run with:  python main.py

On launch:
  - Speaks "JARVIS: SYSTEM ONLINE"
  - Speaks a time-aware greeting ("Good evening, Joseph.")
  - Automatically starts listening in the background — no button press
    needed. Just say "Jarvis" and it replies "Yes, Joseph."

Click "Create Command" to bind a spoken phrase to an application, then say
e.g. "Jarvis, put on some music" to have it launch whatever app you
assigned to that phrase. The "Stop Listening" button lets you pause the
microphone if you want quiet.
"""

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog

from jarvis_core import JarvisEngine

BG = "#0a0e14"
PANEL = "#0f1620"
ACCENT = "#00d4ff"
GREEN = "#00ff9d"
MUTED = "#5c7a99"
TEXT = "#c8d6e5"


class JarvisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("J.A.R.V.I.S.")
        self.root.geometry("640x560")
        self.root.configure(bg=BG)
        self.root.minsize(560, 480)

        self.engine = JarvisEngine(log_callback=self.log)

        self._build_ui()
        self.refresh_command_list()

        # Boot sequence (TTS) runs off the UI thread so the window appears
        # immediately instead of waiting on speech, then the mic switches
        # on automatically so JARVIS is listening without any button press.
        threading.Thread(target=self._boot_and_listen, daemon=True).start()

    def _boot_and_listen(self):
        self.engine.boot()
        self.engine.start_listening()
        self.root.after(0, self._set_listening_ui, True)

    # --------------------------------------------------------------- UI --
    def _build_ui(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", pady=(20, 8))
        tk.Label(header, text="J.A.R.V.I.S.", font=("Consolas", 28, "bold"),
                 fg=ACCENT, bg=BG).pack()
        self.status_label = tk.Label(header, text="● INITIALIZING...", font=("Consolas", 12),
                                      fg=MUTED, bg=BG)
        self.status_label.pack()
        controls = tk.Frame(self.root, bg=BG)
        controls.pack(pady=10)

        self.listen_btn = tk.Button(
            controls, text="\u23F3  Initializing...", font=("Consolas", 11),
            bg="#132030", fg=MUTED, activebackground="#1c3145", activeforeground=ACCENT,
            relief="flat", padx=14, pady=8, command=self.toggle_listening,
            cursor="hand2", state="disabled")
        self.listen_btn.grid(row=0, column=0, padx=6)

        create_btn = tk.Button(
            controls, text="+  Create Command", font=("Consolas", 11),
            bg="#132030", fg=ACCENT, activebackground="#1c3145", activeforeground=ACCENT,
            relief="flat", padx=14, pady=8, command=self.create_command, cursor="hand2")
        create_btn.grid(row=0, column=1, padx=6)

        test_voice_btn = tk.Button(
            controls, text="\U0001F50A  Test Voice", font=("Consolas", 11),
            bg="#132030", fg=ACCENT, activebackground="#1c3145", activeforeground=ACCENT,
            relief="flat", padx=14, pady=8, command=self.test_voice, cursor="hand2")
        test_voice_btn.grid(row=0, column=2, padx=6)

        # Commands list
        list_frame = tk.Frame(self.root, bg=BG)
        list_frame.pack(fill="x", padx=20, pady=(14, 0))
        tk.Label(list_frame, text="COMMANDS", font=("Consolas", 10, "bold"),
                 fg=MUTED, bg=BG).pack(anchor="w")
        self.commands_box = tk.Listbox(
            list_frame, height=6, font=("Consolas", 10), bg=PANEL, fg=TEXT,
            relief="flat", highlightthickness=1, highlightbackground="#1c3145",
            selectbackground="#1c3145", selectforeground=ACCENT)
        self.commands_box.pack(fill="x", pady=4)

        del_btn = tk.Button(
            list_frame, text="Delete Selected", font=("Consolas", 9),
            bg="#1c1010", fg="#ff6b6b", activebackground="#2a1616", relief="flat",
            cursor="hand2", command=self.delete_selected_command)
        del_btn.pack(anchor="e", pady=(2, 0))

        # Log console
        log_frame = tk.Frame(self.root, bg=BG)
        log_frame.pack(fill="both", expand=True, padx=20, pady=14)
        tk.Label(log_frame, text="ACTIVITY LOG", font=("Consolas", 10, "bold"),
                 fg=MUTED, bg=BG).pack(anchor="w")
        self.log_box = tk.Text(
            log_frame, bg=PANEL, fg="#8fd6ff", font=("Consolas", 9), relief="flat",
            highlightthickness=1, highlightbackground="#1c3145", wrap="word")
        self.log_box.pack(fill="both", expand=True, pady=4)
        self.log_box.config(state="disabled")

    # -------------------------------------------------------------- log --
    def log(self, message):
        def append():
            self.log_box.config(state="normal")
            self.log_box.insert("end", message + "\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.root.after(0, append)

    # -------------------------------------------------------- listening --
    def _set_listening_ui(self, is_listening):
        self.listen_btn.config(state="normal")
        if is_listening:
            self.listen_btn.config(text="\u25A0  Stop Listening")
            self.status_label.config(text="● LISTENING...", fg=ACCENT)
        else:
            self.listen_btn.config(text="\U0001F399  Start Listening")
            self.status_label.config(text="● SYSTEM ONLINE (mic off)", fg=GREEN)

    def toggle_listening(self):
        if self.engine._listening:
            self.engine.stop_listening()
            self._set_listening_ui(False)
        else:
            self.engine.start_listening()
            self._set_listening_ui(True)

    def test_voice(self):
        threading.Thread(
            target=lambda: self.engine.speak(
                "Good evening, sir. Systems are functioning within normal parameters."
            ),
            daemon=True,
        ).start()

    # --------------------------------------------------------- commands --
    def create_command(self):
        phrase = simpledialog.askstring(
            "Create Command",
            "What should you say after 'Jarvis'?\n(e.g. \"put on some music\")",
            parent=self.root)
        if not phrase:
            return

        app_path = filedialog.askopenfilename(title="Select the application to launch")
        if not app_path:
            return

        self.engine.add_command(phrase, app_path)
        self.log(f"Command created: 'Jarvis, {phrase}' -> {app_path}")
        self.refresh_command_list()

    def delete_selected_command(self):
        sel = self.commands_box.curselection()
        if not sel:
            return
        line = self.commands_box.get(sel[0])
        phrase = line.split(" \u2192 ")[0].replace("Jarvis, ", "").strip()
        if messagebox.askyesno("Delete Command", f"Delete command '{phrase}'?"):
            self.engine.remove_command(phrase)
            self.refresh_command_list()

    def refresh_command_list(self):
        self.commands_box.delete(0, "end")
        for phrase, path in self.engine.commands.items():
            self.commands_box.insert("end", f"Jarvis, {phrase} \u2192 {path}")


def main():
    root = tk.Tk()
    JarvisApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
