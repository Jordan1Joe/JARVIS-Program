# PyInstaller spec for JARVIS
# Build with:  pyinstaller jarvis.spec
# (run this ON the target OS — Windows produces JARVIS.exe, macOS produces JARVIS.app, Linux produces a JARVIS binary)

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        'pyttsx3.drivers',
        'pyttsx3.drivers.sapi5',   # Windows TTS driver
        'pyttsx3.drivers.nsss',    # macOS TTS driver
        'pyttsx3.drivers.espeak',  # Linux TTS driver
        'edge_tts',
        'pydub',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='JARVIS',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,   # no terminal window — just the GUI
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,       # drop an icon.ico (Windows) / icon.icns (macOS) here if you have one
)
